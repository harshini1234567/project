import tkinter as tk
import random

GRID_SIZE = 6
CANDY_COLORS = ["red", "blue", "green", "yellow", "purple", "orange"]

class CandyCrush:
    def __init__(self, root):
        self.root = root
        self.root.title("Candy Crush Mini Project")
        self.selected = None  # For swapping tiles
        self.buttons = [[None for _ in range(GRID_SIZE)] for _ in range(GRID_SIZE)]
        self.board = [[random.choice(CANDY_COLORS) for _ in range(GRID_SIZE)] for _ in range(GRID_SIZE)]
        self.create_widgets()
        self.check_matches()

    def create_widgets(self):
        for row in range(GRID_SIZE):
            for col in range(GRID_SIZE):
                btn = tk.Button(self.root, bg=self.board[row][col], width=6, height=3,
                                command=lambda r=row, c=col: self.select_tile(r, c))
                btn.grid(row=row, column=col)
                self.buttons[row][col] = btn

    def select_tile(self, row, col):
        if self.selected is None:
            self.selected = (row, col)
            self.buttons[row][col].config(relief=tk.SUNKEN)
        else:
            r1, c1 = self.selected
            r2, c2 = row, col
            if abs(r1 - r2) + abs(c1 - c2) == 1:  # Ensure they are adjacent
                self.swap_tiles(r1, c1, r2, c2)
                if not self.check_matches():
                    # Swap back if no match found
                    self.swap_tiles(r1, c1, r2, c2)
            self.buttons[r1][c1].config(relief=tk.RAISED)
            self.selected = None

    def swap_tiles(self, r1, c1, r2, c2):
        self.board[r1][c1], self.board[r2][c2] = self.board[r2][c2], self.board[r1][c1]
        self.update_board()

    def check_matches(self):
        matched = False
        remove = [[False] * GRID_SIZE for _ in range(GRID_SIZE)]

      
        for r in range(GRID_SIZE):
            for c in range(GRID_SIZE - 2):
                if self.board[r][c] == self.board[r][c+1] == self.board[r][c+2]:
                    remove[r][c] = remove[r][c+1] = remove[r][c+2] = True
                    matched = True

        
        for c in range(GRID_SIZE):
            for r in range(GRID_SIZE - 2):
                if self.board[r][c] == self.board[r+1][c] == self.board[r+2][c]:
                    remove[r][c] = remove[r+1][c] = remove[r+2][c] = True
                    matched = True

        if matched:
            self.remove_matches(remove)
            self.update_board()
        return matched

    def remove_matches(self, remove):
        for c in range(GRID_SIZE):
            new_col = []
            for r in reversed(range(GRID_SIZE)):
                if not remove[r][c]:
                    new_col.append(self.board[r][c])
            while len(new_col) < GRID_SIZE:
                new_col.append(random.choice(CANDY_COLORS))
            for r in range(GRID_SIZE):
                self.board[r][c] = new_col[GRID_SIZE - 1 - r]

    def update_board(self):
        for r in range(GRID_SIZE):
            for c in range(GRID_SIZE):
                self.buttons[r][c].config(bg=self.board[r][c])
        self.root.after(200, self.auto_clear_matches)

    def auto_clear_matches(self):
        while self.check_matches():
            self.update_board()


if __name__ == "__main__":
    root = tk.Tk()
    app = CandyCrush(root)
    root.mainloop()

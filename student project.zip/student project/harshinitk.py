import tkinter as tk
from tkinter import font
import time

def update_time():
    current_time = time.strftime('%H:%M:%S')
    current_date = time.strftime('%A, %d %B %Y')
    clock_label.config(text=current_time)
    date_label.config(text=current_date)
    root.after(1000, update_time)  # Call this function again after 1000ms (1s)


root = tk.Tk()
root.title('Digital Clock')


time_font = font.Font(family='Helvetica', size=60, weight='bold')
date_font = font.Font(family='Helvetica', size=20)


clock_label = tk.Label(root, font=time_font, fg='white', bg='black')
clock_label.pack(pady=20)


date_label = tk.Label(root, font=date_font, fg='white', bg='black')
date_label.pack()


update_time()


root.mainloop()
